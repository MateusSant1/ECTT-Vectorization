# tests/test_equivalence.py
import sys
from pathlib import Path
import random

# Adiciona o diretório raiz do projeto ao sys.path para permitir imports do pacote src
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.rule110_mvp import rule110_sequential, rule110_vectorized


def test_small_deterministic():
    width = 128
    state = [0] * width
    state[width // 2] = 1
    seq = rule110_sequential(state, 50)
    vec = rule110_vectorized(state, 50).tolist()
    assert seq == vec


def test_random_cases():
    for width in (64, 128, 256):
        for _ in range(5):
            state = [random.randint(0, 1) for _ in range(width)]
            gens = random.randint(1, 50)
            seq = rule110_sequential(state, gens)
            vec = rule110_vectorized(state, gens).tolist()
            assert seq == vec
