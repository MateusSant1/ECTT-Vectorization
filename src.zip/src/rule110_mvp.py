import argparse
import numpy as np
import time
import csv
import os
from typing import List, Tuple

# Rule 110 lookup table (index from bits left-center-right as a 3-bit number)
RULE_TABLE = np.array([0,1,1,1,0,1,1,0], dtype=np.uint8)


def rule110_sequential(state: List[int], generations: int) -> List[int]:
    """Sequential (cell-by-cell) implementation of Rule 110.
    state: list of 0/1 ints
    generations: number of generations to simulate
    returns: final state (list of ints)
    """
    n = len(state)
    arr = list(state)
    for _ in range(generations):
        new = [0]*n
        for i in range(n):
            left = arr[(i-1) % n]
            center = arr[i]
            right = arr[(i+1) % n]
            idx = (left << 2) | (center << 1) | right
            new[i] = int(RULE_TABLE[idx])
        arr = new
    return arr


def rule110_vectorized(state: List[int], generations: int) -> np.ndarray:
    """NumPy-vectorized implementation of Rule 110.
    state: list or 1D-array of 0/1 ints
    generations: number of generations to simulate
    returns: final state (numpy array of dtype uint8)
    """
    arr = np.asarray(state, dtype=np.uint8)
    for _ in range(generations):
        left = np.roll(arr, 1)
        center = arr
        right = np.roll(arr, -1)
        idx = (left << 2) | (center << 1) | right  # 0..7
        arr = RULE_TABLE[idx]
    return arr


def verify_equivalence(width: int = 2000, generations: int = 200, trials: int = 3) -> None:
    """Run a few deterministic and random tests to ensure bit-perfect equivalence.
    Raises AssertionError if mismatch found.
    """
    print("Running correctness verification...")

    # Deterministic test: single 1 at center
    state = [0]*width
    state[width//2] = 1
    seq = rule110_sequential(state, generations)
    vec = rule110_vectorized(state, generations).tolist()
    assert seq == vec, "Mismatch on deterministic center-seed test"

    # A couple of random tests
    rng = np.random.default_rng(12345)
    for t in range(trials):
        s = rng.integers(0, 2, size=width).tolist()
        g = max(1, int(generations * 0.1))
        seq = rule110_sequential(s, g)
        vec = rule110_vectorized(s, g).tolist()
        assert seq == vec, f"Mismatch on random test #{t+1}"

    print("✓ Correctness verified: sequential and vectorized outputs match (bit-perfect).")


def benchmark(width: int = 10000, generations: int = 1000, repeats: int = 3, warmups: int = 1) -> Tuple[List[Tuple[str,float,float]], float]:
    """Benchmark both implementations, return results and computed speedup.
    Returns: (results_list, speedup) where results_list contains tuples
    (impl_name, mean_time_s, std_time_s)
    """
    print(f"Running benchmark: width={width}, generations={generations}, repeats={repeats}")
    # initial state: single 1 at position 0 (standard simple seed)
    state = [0]*width
    state[0] = 1

    # warmups
    for _ in range(warmups):
        _ = rule110_vectorized(state, min(10, generations))

    results = []
    for name, func in [("sequential", rule110_sequential), ("vectorized", rule110_vectorized)]:
        times = []
        for i in range(repeats):
            t0 = time.perf_counter()
            _ = func(state, generations)
            t1 = time.perf_counter()
            elapsed = t1 - t0
            times.append(elapsed)
            print(f"  {name} run {i+1}: {elapsed:.4f}s")
        mean_t = float(np.mean(times))
        std_t = float(np.std(times, ddof=1)) if repeats > 1 else 0.0
        results.append((name, mean_t, std_t))

    t_seq = next(r[1] for r in results if r[0] == 'sequential')
    t_vec = next(r[1] for r in results if r[0] == 'vectorized')
    speedup = t_seq / t_vec if t_vec > 0 else float('inf')

    # ensure results directory exists
    os.makedirs('results', exist_ok=True)
    csv_path = os.path.join('results', 'results.csv')
    with open(csv_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['impl', 'mean_time_s', 'std_s', 'width', 'generations', 'repeats'])
        for impl_name, mean_t, std_t in results:
            writer.writerow([impl_name, mean_t, std_t, width, generations, repeats])

    # plot
    os.makedirs(os.path.join('paper', 'figures'), exist_ok=True)
    import matplotlib.pyplot as plt
    labels = [r[0] for r in results]
    times = [r[1] for r in results]
    plt.figure(figsize=(6,4))
    plt.bar(labels, times)
    plt.ylabel('Mean execution time (s)')
    plt.title(f'Rule110: w={width}, g={generations}, speedup={speedup:.2f}x')
    plt.tight_layout()
    figpath = os.path.join('paper', 'figures', 'speedup_chart.png')
    plt.savefig(figpath, dpi=150)
    plt.close()

    print(f"Benchmark complete. Speedup: {speedup:.2f}x")
    print(f"Results saved to {csv_path} and {figpath}")
    return results, speedup


def parse_args():
    p = argparse.ArgumentParser(description='Rule110 MVP: sequential vs vectorized')
    p.add_argument('--width', type=int, default=10000)
    p.add_argument('--gens', type=int, default=1000)
    p.add_argument('--repeats', type=int, default=3)
    p.add_argument('--warmups', type=int, default=1)
    p.add_argument('--verify', action='store_true')
    return p.parse_args()


if __name__ == '__main__':
    args = parse_args()
    if args.verify:
        verify_equivalence(width=min(2000, args.width), generations=min(200, args.gens))
    else:
        # default: run verification first, then benchmark
        verify_equivalence(width=min(2000, args.width), generations=min(200, args.gens))
        benchmark(width=args.width, generations=args.gens, repeats=args.repeats, warmups=args.warmups)
